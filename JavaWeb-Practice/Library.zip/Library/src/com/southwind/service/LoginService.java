package com.southwind.service;

public interface LoginService {
    public Object login(String username,String password,String type);
}
